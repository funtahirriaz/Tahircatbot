import { useState } from "react";
import axios from "axios";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage = { role: "user", content: input };
    setMessages([...messages, userMessage]);

    try {
      const response = await axios.post("https://your-backend-url.com/chat", { message: input });
      const botMessage = { role: "bot", content: response.data.reply };
      setMessages([...messages, userMessage, botMessage]);
    } catch (error) {
      console.error("Error fetching response", error);
    }

    setInput("");
  };

  return (
    <div className="w-96 p-4 bg-gray-800 rounded-lg">
      <div className="h-60 overflow-auto">
        {messages.map((msg, index) => (
          <p key={index} className={msg.role === "user" ? "text-right text-blue-300" : "text-left text-green-300"}>
            {msg.content}
          </p>
        ))}
      </div>
      <div className="flex mt-4">
        <input
          type="text"
          className="flex-1 p-2 rounded-lg text-black"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button className="ml-2 p-2 bg-blue-500 rounded-lg" onClick={sendMessage}>
          Send
        </button>
      </div>
    </div>
  );
}